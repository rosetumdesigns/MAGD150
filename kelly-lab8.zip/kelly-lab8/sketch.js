var map
var jsprite
var jpic

function preload() {
  
  // imgs

  map = loadImage('akolinmini.jpeg')
  jsprite = loadImage('jamie_spritev1.png')
  jpic = loadImage('jamie.png')
  
}


function setup() {
  createCanvas(800, 500);
 
}


function draw() {

  // map
  background(map);
  
  // sprite
  image(jsprite,0,0,mouseX,mouseY);

  // pic
  image(jpic, 0, 0, mouseX * 2, mouseY * 2);


  fill(0);
  stroke(255);
  strokeWeight(3);
  textSize(15);
  textFont('Gotham');
  text('Fast travel to where?', 100, 250, 200, 200);
}