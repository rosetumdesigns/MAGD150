//music
let music;
// webcam
let capture;
//sine wave
let sine;
let freq = 250;

function preload() {
music = loadSound("lowtide-apm.wav");

}

function setup() {
createCanvas (400, 400);

// webcam 
  capture = createCapture();
  capture.hide();


  // sine wave
  sine = new p5.SinOsc();
  sine.start();
}

function draw() {


 // sine wave sound
  var hertz = map(mouseX, 0, 400, 20.0, 440.0);

  sine.freq(hertz);

    background(5);

  //sine wave animation
  for (var z = 0; z < 400; z++) {

    var angle = map(z, 0, 400, 0, TWO_PI * hertz);

    var sinValue = sin(angle) * 120;

    stroke(50);
    line(z, -200, z, 200 + sinValue);

    // webcam perameters
  var aspectRatio = capture.height/capture.width;
  var h = (width/2) * aspectRatio;
  image(capture, 400, 400, (width/2), h);
  filter(POSTERIZE);

  //animation for music

  music.play();

}